-- coordinates for the extra small map, map0xsmall.png --
map.North.xsmall = 52.732983
map.South.xsmall = 52.732099
map.West.xsmall  = 5.274066
map.East.xsmall  = 5.27664
-- No Fly Zone screen coordinates for extra small map --
map.poly.xsmall = {{0,0}, {0,0}, {0,0}, {0,0}, {0,0}}

-- coordinates for the small map, map0small.png --
map.North.small = 52.733425
map.South.small = 52.731657
map.West.small  = 5.272778
map.East.small  = 5.277928
-- No Fly Zone screen coordinates for small map --
map.poly.small = {{0,0}, {0,0}, {0,0}, {0,0}, {0,0}}

-- coordinates for the medium map, map0medium.png --
map.North.medium = 52.734308
map.South.medium = 52.730774
map.West.medium  = 5.270203
map.East.medium  = 5.280503
-- No Fly Zone screen coordinates for medium map --
map.poly.medium = {{0,0}, {0,0}, {0,0}, {0,0}, {0,0}}

-- coordinates for the large map, map0large.png --
map.North.large = 52.736075
map.South.large = 52.729007
map.West.large  = 5.265053
map.East.large  = 5.285653
-- No Fly Zone screen coordinates for large map --
map.poly.large = {{0,0}, {0,0}, {0,0}, {0,0}, {0,0}}

-- coordinates for the extra large map, map0xlarge.png --
map.North.xlarge = 52.739609
map.South.xlarge = 52.725473
map.West.xlarge  = 5.254754
map.East.xlarge  = 5.295952
-- No Fly Zone screen coordinates for extra large map --
map.poly.xlarge = {{0,0}, {0,0}, {0,0}, {0,0}, {0,0}}
